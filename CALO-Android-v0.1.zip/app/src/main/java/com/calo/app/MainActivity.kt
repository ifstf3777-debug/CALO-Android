package com.calo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*

data class Product(val name:String,val kcal:Int,val emoji:String,val protein:Int)

class MainActivity: ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContent { CaloApp() }
    }
}

@Composable
fun CaloApp(){
    val products=listOf(
        Product("Яйцо жареное",120,"🍳",6),
        Product("Кофе с молоком",50,"☕",2),
        Product("Сосиска",120,"🌭",5),
        Product("Курица",200,"🍗",35)
    )
    var kcal by remember { mutableStateOf(0) }
    var protein by remember { mutableStateOf(0) }

    MaterialTheme {
        Surface {
            Column {
                Text("CALO")
                Text("$kcal / 2000 ккал")
                Text("🥩 $protein г белка")
                products.forEach {
                    Button(onClick={
                        kcal += it.kcal
                        protein += it.protein
                    }){
                        Text("${it.emoji} ${it.name} +${it.kcal}")
                    }
                }
            }
        }
    }
}